document.getElementById('button').addEventListener("click", function() {
	document.querySelector('.bg-modal').style.display = "flex";
  
});

document.querySelector('.close').addEventListener("click", function() {
	document.querySelector('.bg-modal').style.display = "none";
  document.querySelector("body").style.overflow = 'visible';
});

document.querySelector('.cl').addEventListener("click", function() {
	document.querySelector('.bg-modal').style.display = "none";
  document.querySelector("body").style.overflow = 'visible';
});

